package com.capgemini.obs.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.obs.dao.BookDao;
import com.capgemini.obs.entity.BookInfo;


@Service
public class BookService {

	@Autowired
	BookDao bookDao;

	 @Transactional
	 public boolean addBook(BookInfo bookInfo)
		{
			return bookDao.save(bookInfo) != null;
		}
	 
	

}
